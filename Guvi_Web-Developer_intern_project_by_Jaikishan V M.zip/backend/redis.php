<?php
// Uses phpredis extension
$redis = new Redis();
$connected = $redis->connect('127.0.0.1', 6379);
if (!$connected) {
    // We'll still let code run; session operations should check for availability.
}
?>