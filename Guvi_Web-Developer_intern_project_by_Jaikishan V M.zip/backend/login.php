<?php
require_once 'db.php';
require_once 'redis.php';
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$email = $input['email'] ?? '';
$password = $input['password'] ?? '';

if (!$email || !$password) {
    echo json_encode(['status'=>'error','message'=>'Missing fields']);
    exit;
}

$stmt = $conn->prepare('SELECT id, password FROM users WHERE email = ?');
$stmt->bind_param('s', $email);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows !== 1) {
    echo json_encode(['status'=>'error','message'=>'User not found']);
    exit;
}
$stmt->bind_result($id, $hash);
$stmt->fetch();

if (!password_verify($password, $hash)) {
    echo json_encode(['status'=>'error','message'=>'Invalid credentials']);
    exit;
}

// create session token
$token = bin2hex(random_bytes(16));
if (isset($redis) && $redis instanceof Redis) {
    $redis->set('session:'.$token, $id);
    // set expiry (e.g., 1 day)
    $redis->expire('session:'.$token, 86400);
}
echo json_encode(['status'=>'success','token'=>$token]);
?>