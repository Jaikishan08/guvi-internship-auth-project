<?php
// MySQL connection (mysqli)
$host = '127.0.0.1';
$dbname = 'guvi';
$user = 'root';
$pass = '';

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['status'=>'error','message'=>'DB connection failed']);
    exit;
}
$conn->set_charset('utf8mb4');
?>