<?php
require_once 'db.php';
header('Content-Type: application/json');
$input = json_decode(file_get_contents('php://input'), true);
if (!$input) { echo json_encode(['status'=>'error','message'=>'Invalid input']); exit; }

$full_name = trim($input['full_name'] ?? '');
$email = trim($input['email'] ?? '');
$password = $input['password'] ?? '';

if (!$full_name || !$email || !$password) {
    echo json_encode(['status'=>'error','message'=>'Missing fields']);
    exit;
}

$hashed = password_hash($password, PASSWORD_BCRYPT);

$stmt = $conn->prepare('INSERT INTO users (full_name, email, password) VALUES (?, ?, ?)');
if (!$stmt) {
    echo json_encode(['status'=>'error','message'=>'Prepare failed']);
    exit;
}
$stmt->bind_param('sss', $full_name, $email, $hashed);

if ($stmt->execute()) {
    echo json_encode(['status'=>'success']);
} else {
    // duplicate or other error
    echo json_encode(['status'=>'error','message'=>'Email may already be registered']);
}
?>