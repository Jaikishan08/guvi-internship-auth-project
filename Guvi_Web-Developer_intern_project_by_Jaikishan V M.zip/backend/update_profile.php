<?php
require_once 'redis.php';
require_once 'mongo.php';
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$token = $input['token'] ?? '';

if (!$token) {
    echo json_encode(['status'=>'error','message'=>'No token provided']);
    exit;
}

$user_id = null;
if (isset($redis) && $redis instanceof Redis) {
    $user_id = $redis->get('session:'.$token);
}
if (!$user_id) {
    echo json_encode(['status'=>'error','message'=>'Invalid or expired session']);
    exit;
}

// sanitize data (basic)
$age = $input['age'] ?? null;
$dob = $input['dob'] ?? null;
$contact = $input['contact'] ?? null;
$address = $input['address'] ?? null;

$doc = [
    'user_id' => (int)$user_id,
    'age' => $age,
    'dob' => $dob,
    'contact' => $contact,
    'address' => $address,
    'updated_at' => new MongoDB\BSON\UTCDateTime()
];

$filter = ['user_id' => (int)$user_id];
$options = ['upsert' => true];
$result = $profiles->updateOne($filter, ['$set' => $doc], $options);

echo json_encode(['status'=>'success']);
?>