$(function(){
  $("#registerForm").on("submit", function(e){
    e.preventDefault();
    const data = {
      full_name: $("[name='full_name']").val(),
      email: $("[name='email']").val(),
      password: $("[name='password']").val()
    };
    $.ajax({
      url: "backend/register.php",
      method: "POST",
      data: JSON.stringify(data),
      contentType: "application/json",
      success: function(res){
        try { res = typeof res === 'string' ? JSON.parse(res) : res; } catch(e){}
        if (res.status === 'success') {
          alert('Registered successfully. Please login.');
          window.location.href = 'index.html';
        } else {
          alert(res.message || 'Error registering');
        }
      },
      error: function(){ alert('Network or server error'); }
    });
  });
});
