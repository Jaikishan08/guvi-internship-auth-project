$(function(){
  const token = localStorage.getItem('token');
  if (!token) { window.location.href='index.html'; return; }

  $("#logoutBtn").on('click', function(){
    localStorage.removeItem('token');
    window.location.href = 'index.html';
  });

  // Load existing profile (optional endpoint could be added). For now user updates only.
  $("#profileForm").on("submit", function(e){
    e.preventDefault();
    const data = {
      token: token,
      age: $("[name='age']").val(),
      dob: $("[name='dob']").val(),
      contact: $("[name='contact']").val(),
      address: $("[name='address']").val()
    };
    $.ajax({
      url: "backend/update_profile.php",
      method: "POST",
      data: JSON.stringify(data),
      contentType: "application/json",
      success: function(res){
        try { res = typeof res === 'string' ? JSON.parse(res) : res; } catch(e){}
        if (res.status === 'success') {
          alert('Profile updated.');
        } else {
          alert(res.message || 'Update failed');
        }
      },
      error: function(){ alert('Network or server error'); }
    });
  });
});
