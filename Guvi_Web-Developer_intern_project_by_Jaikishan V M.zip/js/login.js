$(function(){
  $("#loginForm").on("submit", function(e){
    e.preventDefault();
    const data = {
      email: $("[name='email']").val(),
      password: $("[name='password']").val()
    };
    $.ajax({
      url: "backend/login.php",
      method: "POST",
      data: JSON.stringify(data),
      contentType: "application/json",
      success: function(res){
        try { res = typeof res === 'string' ? JSON.parse(res) : res; } catch(e){}
        if (res.status === 'success') {
          localStorage.setItem('token', res.token);
          window.location.href = 'profile.html';
        } else {
          alert(res.message || 'Login failed');
        }
      },
      error: function(){ alert('Network or server error'); }
    });
  });
});
